# telegram_notifier.py
import os
import time
from datetime import datetime
import requests

# (Opcional) pip install python-dotenv
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

_last = {"key": None, "ts": 0}

def _cooldown(key: str, seconds: int) -> bool:
    now = time.time()
    if _last["key"] != key or now - _last["ts"] >= seconds:
        _last["key"], _last["ts"] = key, now
        return True
    return False

def send_message(text: str, parse_mode: str = "Markdown"):
    if not BOT_TOKEN or not CHAT_ID:
        print("⚠️ TELEGRAM: defina TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID no ambiente.")
        return False
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": text, "parse_mode": parse_mode, "disable_web_page_preview": True}
    try:
        r = requests.post(url, json=payload, timeout=10)
        if not r.ok: print(f"⚠️ TELEGRAM erro: {r.status_code} {r.text}")
        return r.ok
    except Exception as e:
        print(f"⚠️ TELEGRAM exceção: {e}")
        return False

def notify_signal(symbol: str, signal: str, price: float,
                  rsi=None, ma_fast=None, ma_slow=None,
                  lucro_pct=None, decisao=None, cooldown_sec: int = 900):
    """
    Envia msg curta; usa cooldown por (symbol:signal) para evitar spam.
    """
    key = f"{symbol}:{signal}"
    if not _cooldown(key, cooldown_sec):
        return False

    titulo = "🟢 COMPRA" if signal == "buy" else ("🔴 VENDA" if signal == "sell" else "⏸️ HOLD")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    linhas = [
        f"*{titulo}* — *{symbol}*",
        f"💵 Preço: `${price:.4f}`",
    ]
    if rsi is not None:     linhas.append(f"🎯 RSI: `{float(rsi):.2f}`")
    if ma_fast is not None: linhas.append(f"📈 MA 9: `{float(ma_fast):.4f}`")
    if ma_slow is not None: linhas.append(f"📉 MA 21: `{float(ma_slow):.4f}`")
    if lucro_pct is not None: linhas.append(f"📊 P/L atual: `{float(lucro_pct):+.2f}%`")
    if decisao: linhas.append(f"🧭 Decisão: *{decisao}*")
    linhas.append(f"🕒 {ts}")

    return send_message("\n".join(linhas))
