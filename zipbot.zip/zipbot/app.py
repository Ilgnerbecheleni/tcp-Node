import pandas as pd
import numpy as np
import requests
import time
from datetime import datetime, timedelta
import warnings
from telegram_notifier import notify_signal 
warnings.filterwarnings('ignore')

class POLTradingBotReal:
    def __init__(self):
        self.api_url = "https://api.binance.com/api/v3"
        self.symbol = "POLUSDT"
        self.interval = "1h"
        
        # SUA POSIÇÃO REAL NA BINANCE
        self.posicao_real = True  # Você está posicionado
        self.quantidade_pol = 92.0  # Seus 92 POL
        self.preco_medio_compra = 0.269  # Seu preço médio
        self.investimento_inicial = 92.0 * 0.274  # ≈ $25.21
        
        # Estado atual do bot
        self.preco_entrada_bot = 0
        self.horario_entrada = None
        self.operacoes = []
        
        print(f"🎯 BOT CONFIGURADO COM SUA POSIÇÃO REAL")
        print(f"📦 POL em carteira: {self.quantidade_pol:.2f}")
        print(f"💰 Preço médio: ${self.preco_medio_compra:.4f}")
        print(f"💵 Investimento inicial: ${self.investimento_inicial:.2f}")
        print("=" * 60)
    
    def get_realtime_data(self, limit=100):
        """Obtém dados em tempo real"""
        try:
            url = f"{self.api_url}/klines"
            params = {
                'symbol': self.symbol,
                'interval': self.interval,
                'limit': limit
            }
            
            response = requests.get(url, params=params)
            data = response.json()
            
            df = pd.DataFrame(data, columns=[
                'open_time', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_asset_volume', 'number_of_trades',
                'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
            ])
            
            numeric_columns = ['open', 'high', 'low', 'close', 'volume']
            for col in numeric_columns:
                df[col] = df[col].astype(float)
            
            df['timestamp'] = pd.to_datetime(df['open_time'], unit='ms')
            df.set_index('timestamp', inplace=True)
            
            return df[['open', 'high', 'low', 'close', 'volume']]
            
        except Exception as e:
            print(f"❌ Erro ao obter dados: {e}")
            return None
    
    def get_current_price(self):
        """Obtém preço atual"""
        try:
            url = f"{self.api_url}/ticker/price"
            params = {'symbol': self.symbol}
            response = requests.get(url, params=params)
            data = response.json()
            return float(data['price'])
        except Exception as e:
            print(f"❌ Erro ao obter preço: {e}")
            return None
    
    def calculate_indicators(self, df):
        """Calcula indicadores técnicos"""
        df = df.copy()
        
        # Médias Móveis
        df['ma_fast'] = df['close'].rolling(window=9).mean()
        df['ma_slow'] = df['close'].rolling(window=21).mean()
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # Volume
        df['volume_ma'] = df['volume'].rolling(window=20).mean()
        
        return df
    
    def trading_strategy(self, df, verbose=True):
        """Estratégia de trading"""
        if len(df) < 30:
            return 'hold'
        
        current = df.iloc[-1]
        previous = df.iloc[-2]
        
        # Condições de COMPRA (para comprar mais)
        golden_cross = (previous['ma_fast'] <= previous['ma_slow'] and 
                       current['ma_fast'] > current['ma_slow'])
        rsi_oversold = current['rsi'] < 35
        volume_spike = current['volume'] > current['volume_ma'] * 1.8
        buy_conditions = golden_cross and rsi_oversold and volume_spike
        
        # Condições de VENDA (para vender tudo ou parte)
        death_cross = (previous['ma_fast'] >= previous['ma_slow'] and 
                      current['ma_fast'] < current['ma_slow'])
        rsi_overbought = current['rsi'] > 65
        price_below_slow_ma = current['close'] < current['ma_slow']
        sell_conditions = death_cross or rsi_overbought or price_below_slow_ma
        
        if verbose:
            print(f"\n📊 ANÁLISE {self.symbol} - {datetime.now().strftime('%H:%M:%S')}")
            print("=" * 50)
            print(f"💰 Preço: ${current['close']:.4f}")
            print(f"📈 MA Rápida: ${current['ma_fast']:.4f}")
            print(f"📉 MA Lenta: ${current['ma_slow']:.4f}")
            print(f"🎯 RSI: {current['rsi']:.2f}")
            print(f"📊 Volume: {current['volume']:,.0f}")
            
            print(f"\n⚡ SINAIS:")
            print(f"Golden Cross: {'✅' if golden_cross else '❌'}")
            print(f"RSI Oversold: {'✅' if rsi_oversold else '❌'}")
            print(f"Death Cross: {'✅' if death_cross else '❌'}")
            print(f"RSI Overbought: {'✅' if rsi_overbought else '❌'}")
        
        if buy_conditions:
            if verbose:
                print("\n🎯 SINAL: COMPRA 🟢")
            return 'buy'
        elif sell_conditions:
            if verbose:
                print("\n🎯 SINAL: VENDA 🔴")
            return 'sell'
        else:
            return 'hold'
    
    def calcular_lucro_atual(self, preco_atual):
        """Calcula lucro/prejuízo atual"""
        valor_atual = self.quantidade_pol * preco_atual
        lucro = valor_atual - self.investimento_inicial
        lucro_percentual = (lucro / self.investimento_inicial) * 100
        return lucro, lucro_percentual, valor_atual
    
    def tomar_decisao_inteligente(self, sinal_tecnico, preco_atual):
        """Toma decisão considerando sua posição real"""
        
        lucro, lucro_percentual, valor_atual = self.calcular_lucro_atual(preco_atual)
        
        print(f"\n💼 SUA POSIÇÃO REAL")
        print(f"📦 POL: {self.quantidade_pol:.2f}")
        print(f"💰 Preço médio: ${self.preco_medio_compra:.4f}")
        print(f"💵 Valor atual: ${valor_atual:.2f}")
        print(f"📈 Lucro: ${lucro:+.2f} ({lucro_percentual:+.2f}%)")
        print("=" * 50)
        
        # VOCÊ JÁ ESTÁ POSICIONADO - decisões diferentes
        if sinal_tecnico == 'sell':
            # SINAL DE VENDA - avaliar se vale a pena vender
            if lucro_percentual > 10:  # Lucro acima de 10%
                print("🎯 DECISÃO: VENDER TUDO 🔴")
                print("👉 Bom lucro + Sinal técnico de venda")
                return 'vender_tudo'
                
            elif lucro_percentual < -15:  # Stop-loss de -15%
                print("🎯 DECISÃO: VENDER TUDO (Stop-loss) 🔴")
                print("👉 Limite de perda atingido")
                return 'vender_tudo'
                
            else:
                print("🎯 DECISÃO: SEGURAR ⏳")
                print("👉 Sinal de venda, mas lucro pequeno ou prejuízo controlado")
                return 'manter'
        
        elif sinal_tecnico == 'buy':
            # SINAL DE COMPRA - avaliar se compra mais
            if lucro_percentual < -5:  # Média para baixo
                print("🎯 DECISÃO: COMPRAR MAIS 🟢")
                print("👉 Média para baixo + Sinal técnico bom")
                return 'comprar_mais'
            else:
                print("🎯 DECISÃO: SEGURAR ⏳")
                print("👉 Já posicionado com bom lucro")
                return 'manter'
        
        else:
            # SINAL NEUTRO - monitorar
            if lucro_percentual > 20:
                print("🎯 DECISÃO: PENSAR EM VENDER ⚠️")
                print("👉 Lucro alto, considerar realizar ganhos")
            elif lucro_percentual < -10:
                print("🎯 DECISÃO: FICAR ATENTO ⚠️")
                print("👉 Prejuízo significativo, monitorar closely")
            else:
                print("🎯 DECISÃO: AGUARDAR ⏳")
                print("👉 Posição estável, aguardar sinais claros")
            
            return 'aguardar'
    
    def simular_operacao(self, decisao, preco_atual):
        """Simula a operação baseada na decisão"""
        
        if decisao == 'vender_tudo':
            lucro, lucro_percentual, _ = self.calcular_lucro_atual(preco_atual)
            print(f"\n✅ SIMULAÇÃO: VENDA EXECUTADA")
            print(f"💰 Valor realizado: ${self.quantidade_pol * preco_atual:.2f}")
            print(f"📈 Lucro final: ${lucro:+.2f} ({lucro_percentual:+.2f}%)")
            print("👉 Você venderia seus 92 POL")
           
        elif decisao == 'comprar_mais':
            # Sugere comprar mais 10% do que já tem
            quantidade_extra = self.quantidade_pol * 0.1
            custo_extra = quantidade_extra * preco_atual
            print(f"\n✅ SIMULAÇÃO: COMPRA ADICIONAL")
            print(f"📦 Compraria: {quantidade_extra:.2f} POL extras")
            print(f"💵 Custo: ${custo_extra:.2f}")
            print(f"📊 Novo preço médio: ${((self.investimento_inicial + custo_extra) / (self.quantidade_pol + quantidade_extra)):.4f}")
            
        else:
            print(f"\n⏳ Mantendo posição atual")
    
    def monitorar_sua_posicao(self, intervalo_minutos=15):
        """Monitora sua posição específica"""
        print("🔍 MONITORANDO SUA POSIÇÃO DE 92 POL")
        print(f"⏰ Intervalo: {intervalo_minutos} minutos")
        print("🛑 Pressione Ctrl+C para parar")
        print("=" * 60)
        
        while True:
            try:
                df = self.get_realtime_data()
                preco_atual = self.get_current_price()
                
                if df is not None and preco_atual is not None:
                    df_com_indicadores = self.calculate_indicators(df)
                    sinal = self.trading_strategy(df_com_indicadores, verbose=True)
                    
                    print(f"💵 Preço atual: ${preco_atual:.4f}")
                    
                    # Toma decisão considerando SUA posição
                    decisao = self.tomar_decisao_inteligente(sinal, preco_atual)
                    
                    # Simula a operação
                    self.simular_operacao(decisao, preco_atual)

                    # --- TELEGRAM: INÍCIO ---
                    candle = df_com_indicadores.iloc[-1]
                    rsi = candle['rsi'] if 'rsi' in candle else None
                    ma_fast = candle['ma_fast'] if 'ma_fast' in candle else None
                    ma_slow = candle['ma_slow'] if 'ma_slow' in candle else None
                    _, lucro_pct, _ = self.calcular_lucro_atual(preco_atual)

                    # A) Alerta por SINAL técnico (quando nascer buy/sell)
                    if sinal in ('buy', 'sell'):
                        notify_signal(
                            symbol=self.symbol,
                            signal=sinal,
                            price=preco_atual,
                            rsi=(float(rsi) if rsi is not None and pd.notna(rsi) else None),
                            ma_fast=(float(ma_fast) if ma_fast is not None and pd.notna(ma_fast) else None),
                            ma_slow=(float(ma_slow) if ma_slow is not None and pd.notna(ma_slow) else None),
                            lucro_pct=float(lucro_pct),
                            decisao=None,
                            cooldown_sec=900
                        )

                    # B) Alerta por DECISÃO operacional (agir: comprar_mais / vender_tudo)
                    if decisao in ('comprar_mais', 'vender_tudo'):
                        notify_signal(
                            symbol=self.symbol,
                            signal=('buy' if decisao == 'comprar_mais' else 'sell'),
                            price=preco_atual,
                            rsi=(float(rsi) if rsi is not None and pd.notna(rsi) else None),
                            ma_fast=(float(ma_fast) if ma_fast is not None and pd.notna(ma_fast) else None),
                            ma_slow=(float(ma_slow) if ma_slow is not None and pd.notna(ma_slow) else None),
                            lucro_pct=float(lucro_pct),
                            decisao=decisao,
                            cooldown_sec=900
                        )
                    # --- TELEGRAM: FIM ---
                    
                    print("\n" + "=" * 60)
                    print(f"⏳ Próxima análise em {intervalo_minutos} minutos...")
                    print("=" * 60)
                
                time.sleep(intervalo_minutos * 60)
                
            except KeyboardInterrupt:
                print("\n⏹️ Monitoramento interrompido")
                break
            except Exception as e:
                print(f"❌ Erro: {e}")
                time.sleep(60)

# Função para análise rápida da sua posição
def analise_sua_posicao():
    """Análise rápida da sua posição específica"""
    print("📈 ANÁLISE DA SUA POSIÇÃO DE 92 POL")
    print("=" * 60)
    
    bot = POLTradingBotReal()
    
    df = bot.get_realtime_data()
    preco_atual = bot.get_current_price()
    
    if df is not None and preco_atual is not None:
        df_com_indicadores = bot.calculate_indicators(df)
        sinal = bot.trading_strategy(df_com_indicadores, verbose=True)
        
        print(f"💵 Preço atual: ${preco_atual:.4f}")
        
        # Análise detalhada da sua posição
        lucro, lucro_percentual, valor_atual = bot.calcular_lucro_atual(preco_atual)
        
        print(f"\n📊 SUA SITUAÇÃO:")
        print(f"💰 Investido: ${bot.investimento_inicial:.2f}")
        print(f"📈 Valor atual: ${valor_atual:.2f}")
        print(f"🎯 Lucro/Prejuízo: ${lucro:+.2f} ({lucro_percentual:+.2f}%)")
        
        # --- TELEGRAM: INÍCIO (opcional: alerta único na análise rápida) ---
        candle = df_com_indicadores.iloc[-1]
        rsi = candle['rsi'] if 'rsi' in candle else None
        ma_fast = candle['ma_fast'] if 'ma_fast' in candle else None
        ma_slow = candle['ma_slow'] if 'ma_slow' in candle else None
        if sinal in ('buy', 'sell'):
            notify_signal(
                symbol=bot.symbol,
                signal=sinal,
                price=preco_atual,
                rsi=(float(rsi) if rsi is not None and pd.notna(rsi) else None),
                ma_fast=(float(ma_fast) if ma_fast is not None and pd.notna(ma_fast) else None),
                ma_slow=(float(ma_slow) if ma_slow is not None and pd.notna(ma_slow) else None),
                lucro_pct=float((lucro / bot.investimento_inicial) * 100),
                decisao=None,
                cooldown_sec=900
            )
        # --- TELEGRAM: FIM ---
        
        # Recomendação
        if lucro_percentual > 20:
            print("\n💡 RECOMENDAÇÃO: Considerar realizar lucros")

        elif lucro_percentual > 0:
            print("\n💡 RECOMENDAÇÃO: Manter posição")
        else:
            print("\n💡 RECOMENDAÇÃO: Aguardar recuperação")
        
        return sinal, preco_atual
    
    return 'hold', None

if __name__ == "__main__":
    print("🤖 BOT PARA SUA POSIÇÃO DE 92 POL")
    print("1 - Análise rápida da posição")
    print("2 - Monitoramento contínuo")
    
    escolha = input("\nEscolha (1 ou 2): ").strip()
    
    if escolha == "2":
        bot = POLTradingBotReal()
        intervalo = int(input("Intervalo em minutos (padrão 15): ") or "15")
        bot.monitorar_sua_posicao(intervalo)
    else:
        analise_sua_posicao()
