from telegram_notifier import notify_signal

# Simula envio de um alerta de compra
notify_signal(
    symbol="POLUSDT",
    signal="buy",        # ou "sell"
    price=0.285,
    rsi=32.5,
    ma_fast=0.280,
    ma_slow=0.278,
    lucro_pct=4.5,
    decisao="comprar_mais"   # ou "vender_tudo" / None
)
