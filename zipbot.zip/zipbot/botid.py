import requests

TOKEN = "8166263696:AAFpN0qFltzuX06fsXIKJYdCWBpVAerevlE"

url = f"https://api.telegram.org/bot{TOKEN}/getUpdates"
resp = requests.get(url).json()

print(resp)

if "result" in resp and len(resp["result"]) > 0:
    chat_id = resp["result"][0]["message"]["chat"]["id"]
    print(f"✅ Seu chat_id é: {chat_id}")
else:
    print("⚠️ Nenhuma mensagem encontrada. Envie uma mensagem para o bot primeiro.")
